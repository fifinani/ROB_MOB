

#include <stdlib.h>
#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <vector>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>


using namespace std;

//void FindElem(/*vector<int> vect, int k*/){
    // Check if element 22 exists in vector
    /*std::vector<int>::iterator it = std::find(vect.begin(), vect.end(), k);
    if (it != vect.end()){
        std::cout << "Element Found" << std::endl;
        return 1;
    }
    else{
        std::cout << "Element Not Found" << std::endl;
        return 0;
    }*/
  /*  return ;
}*/

void  test(int k){
  return ;
}
